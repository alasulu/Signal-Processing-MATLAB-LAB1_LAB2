clear
clc

%--- 1. Getting Started ---%
z = 3+ 4i;
w = -3 + 4j;
real_z = real(z);
imag_z = imag(z);
abs_zw = abs([z,w]); % <-- Vector Constructor
conj_zw = conj(z+w); %     conj(X) is the complex conjugate of X. 
%For a complex X, conj(X) = REAL(X) - i*IMAG(X).
angle_z = angle(z);
a = exp(j*pi); % Amplitude is always 1 (sqrt((-1)^2 + (0)^2))
b = exp(j*[pi/4,0,-pi/4]);

%--- 2. Warm Up ---%
jkl = 2 : 4 : 17;
jkl_2 = 2 : -1/9 : 0;
tpi = pi * [0:0.1:2];
xx = [ zeros(1,3), linspace(0,1,5), ones(1,4)];
xx_selected = xx(4:6);
size_xx = size(xx);
len_xx = length(xx);
len_xx2 = xx(2:2:len_xx);

%--- 3. MATLAB Script Files ---%
xk = cos(pi*(0:11)/4);
yy = [];
for k=-5:5
    yy(k+6) = cos(k*pi/3);
end
disp(yy)
x = [-3 -1 0 1 3 ];
y = x.*x - 3*x;
plot(x,y)
z = x + y*sqrt(-1);
plot(z) %<---- complex values: plot imag vs. real

