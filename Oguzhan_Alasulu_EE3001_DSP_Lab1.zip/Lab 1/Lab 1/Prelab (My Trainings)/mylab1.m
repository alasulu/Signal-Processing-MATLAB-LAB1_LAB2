clear
clc
tt=-1: 0.01: 1;
xx = cos(5*pi*tt);
zz = 1.4*exp(j*pi/2)*exp(j*5*pi*tt);
plot( tt, xx,'b-', tt, real(zz), 'r--' ), 
grid on
title("TEST PLOT of a SINUSOID")
xlabel("TIME (sec)")
legend('tt vs. xx','tt vs. real(zz)')
%xpsound 
xx2 = cos(5*pi*tt);
zz2 = 1.4*exp(j*pi/2)*exp(j*5*pi*tt);
dur = 0.9;
fs = 11025;
tt = 0:(1/fs):dur;
freq_sin_tone = sin(2*pi*2000*tt);
soundsc(freq_sin_tone,fs)